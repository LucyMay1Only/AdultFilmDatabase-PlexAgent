# =======================================================================
# Adult Film Database (AFDB) Metadata Agent for Plex
# 
# Copyright (c) 2026 Lucy May & G. Antidote
# All Rights Reserved.
# 
# This source code is proprietary and confidential. Unauthorized copying,
# modification, or distribution of this file, via any medium, is strictly 
# prohibited without the express written consent of the authors.
# =======================================================================

import re
import urllib

AFDB_BASE_URL = 'https://www.adultfilmdatabase.com'
AFDB_SEARCH_URL = AFDB_BASE_URL + '/lookup.cfm'

# HTTP Timeout
HTTP_TIMEOUT = 10

def Start():
    HTTP.ClearCache()
    HTTP.Headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

class AdultFilmDatabaseAgent(Agent.Movies):
    name = 'Adult Film Database'
    languages = [Locale.Language.English]
    primary_provider = True
    accepts_from = ['com.plexapp.agents.localmedia']

    def search(self, results, media, lang):
        title = media.name or (media.primary_metadata.title if media.primary_metadata else '')
        if not title:
            return

        query = String.StripDiacritics(title)
        
        # Use quote_plus for query params
        encoded_query = urllib.quote_plus(query.encode('utf-8'))
        data = 'find=' + encoded_query + '&exact=0&searchType=All'
        
        try:
            req = HTTP.Request(AFDB_SEARCH_URL, data=data, headers={'Content-Type': 'application/x-www-form-urlencoded'}, timeout=HTTP_TIMEOUT)
            html = HTML.ElementFromString(req.content)
            
            seen = set()
            
            # The search results have <a href="/video/84180/just-us-girls/" title="Just Us Girls">
            for a_tag in html.xpath('//a[contains(@href, "/video/")]'):
                href = a_tag.get('href')
                name = a_tag.get('title')
                
                if not href or not name:
                    continue
                    
                match = re.search(r'/video/(\d+)/([^/]+)', href)
                if match:
                    movie_id = match.group(1)
                    slug = match.group(2)
                    compound_id = '%s|%s' % (movie_id, slug)
                    
                    if compound_id not in seen:
                        seen.add(compound_id)
                        
                        score = 100 - Util.LevenshteinDistance(query.lower(), name.lower())
                        
                        results.Append(MetadataSearchResult(
                            id=compound_id, 
                            name=name, 
                            score=score, 
                            lang=lang
                        ))
                        
            results.Sort('score', descending=True)
            Log('AFDB: Search completed with %d results' % len(seen))
            
        except Exception as e:
            Log('AFDB Search Error: ' + str(e))

    def update(self, metadata, media, lang):
        if not metadata.id or '|' not in metadata.id:
            return
            
        movie_id, slug = metadata.id.split('|')
        url = '%s/video/%s/%s/' % (AFDB_BASE_URL, movie_id, slug)
        Log('AFDB: Updating metadata for %s' % url)
        
        try:
            req = HTTP.Request(url, timeout=HTTP_TIMEOUT)
            html = HTML.ElementFromString(req.content)
            
            # Title
            title_node = html.xpath('//h1[@itemprop="name"]')
            if title_node:
                metadata.title = title_node[0].text_content().strip()
                
            # Summary
            summary_node = html.xpath('//p[@itemprop="description"]')
            if summary_node:
                metadata.summary = summary_node[0].text_content().replace('Description:', '').strip()
                
            # Studio
            studio_node = html.xpath('//a[contains(@href, "/studio/")]')
            if studio_node:
                metadata.studio = studio_node[0].text_content().strip()
                metadata.collections.clear()
                metadata.collections.add(metadata.studio)
                
            # Directors
            director_nodes = html.xpath('//span[@itemprop="director"]//span[@itemprop="name"]')
            metadata.directors.clear()
            for d in director_nodes:
                name = d.text_content().strip()
                if name:
                    director = metadata.directors.new()
                    director.name = name
                    
            # Cast
            cast_nodes = html.xpath('//span[@itemprop="actor"]')
            metadata.roles.clear()
            for cast_node in cast_nodes:
                name_node = cast_node.xpath('.//p[@itemprop="name"]')
                if name_node:
                    role = metadata.roles.new()
                    role.name = name_node[0].text_content().strip()
                    
                    # Look for image
                    parent_div = cast_node.xpath('..')
                    if parent_div:
                        img_node = parent_div[0].xpath('.//img')
                        if img_node:
                            img_src = img_node[0].get('src')
                            if img_src and not img_src.endswith('NoImage.gif'):
                                if not img_src.startswith('http'):
                                    img_src = AFDB_BASE_URL + img_src
                                role.photo = img_src
                                
            # Posters (Front/Back box covers are usually main image)
            poster_node = html.xpath('//img[@itemprop="image"]')
            if poster_node:
                poster_src = poster_node[0].get('src')
                if poster_src:
                    full_src = poster_src.replace('/200/', '/350/')
                    if not full_src.startswith('http'):
                        full_src = AFDB_BASE_URL + full_src
                        poster_src = AFDB_BASE_URL + poster_src
                    
                    Log('AFDB: Found Poster URL %s' % full_src)
                    try:
                        metadata.posters[full_src] = Proxy.Preview(HTTP.Request(poster_src).content)
                    except:
                        metadata.posters[poster_src] = Proxy.Preview(HTTP.Request(poster_src).content)
            
            # Series
            series_node = html.xpath('//a[contains(@href, "/videoseries/")]//div[contains(text(), "Series")]')
            if series_node:
                series_name = series_node[0].text_content().replace('Series', '').strip()
                if series_name:
                    metadata.collections.add(series_name)
                    
            # Genres
            genres_nodes = html.xpath('//a[contains(@href, "cf=")]//span')
            metadata.genres.clear()
            for genre_node in genres_nodes:
                genre = genre_node.text_content().strip()
                if genre:
                    metadata.genres.add(genre)
                    
        except Exception as e:
            Log('AFDB Update Error: ' + str(e))
